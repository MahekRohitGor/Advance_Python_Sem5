def my_fun():
           print("PDEU")
print("I am in test file")
if __name__ == "__main__":
          print("test.py will run as standalone")
else:
          print("test.py will run only when imported")